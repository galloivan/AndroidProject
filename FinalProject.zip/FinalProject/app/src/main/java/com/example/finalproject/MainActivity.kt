package com.example.finalproject

import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.FragmentContainerView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val signInButton: Button = findViewById(R.id.signInButton)
        val signUpButton: Button = findViewById(R.id.signUpButton)
        val browseAsGuestButton: Button = findViewById(R.id.browseAsGuestButton)
        val fragmentContainer: FragmentContainerView = findViewById(R.id.fragmentContainer)

        signInButton.setOnClickListener {
            // Implement your logic to navigate to the Sign In screen
        }

        signUpButton.setOnClickListener {
            // Implement your logic to navigate to the Sign Up screen
        }

        browseAsGuestButton.setOnClickListener {
            // Hide the buttons and the title
            signInButton.visibility = View.GONE
            signUpButton.visibility = View.GONE
            browseAsGuestButton.visibility = View.GONE
            findViewById<View>(R.id.titleTextView).visibility = View.GONE

            // Now, show the FragmentContainerView and add your fragment
            fragmentContainer.visibility = View.VISIBLE

            // Replace whatever is in the fragmentContainer view with this fragment
            supportFragmentManager.beginTransaction().apply {
                replace(R.id.fragmentContainer, ServiceSelectionFragment())
                // The line below is commented out; uncomment if you want to add the transaction to the back stack
                // addToBackStack(null)
                commit()
            }
        }
    }
}
